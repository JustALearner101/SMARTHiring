const API_BASE_URL =
  process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000/api/v1";

export interface ApiRequestOptions extends RequestInit {
  token?: string;
}

export class ApiError extends Error {
  status: number;
  data: unknown;

  constructor(message: string, status: number, data?: unknown) {
    super(message);
    this.name = "ApiError";
    this.status = status;
    this.data = data;
  }
}

export async function apiFetch<T>(
  endpoint: string,
  options: ApiRequestOptions = {}
): Promise<T> {
  const { token, headers, ...restOptions } = options;

  const storedToken =
    typeof window !== "undefined" ? localStorage.getItem("auth_token") : null;
  const storedRole =
    typeof window !== "undefined" ? localStorage.getItem("auth_role") : null;
  const activeToken = token || storedToken;

  const url = endpoint.startsWith("http")
    ? endpoint
    : `${API_BASE_URL.replace(/\/$/, "")}/${endpoint.replace(/^\//, "")}`;

  const response = await fetch(url, {
    ...restOptions,
    headers: {
      "Content-Type": "application/json",
      ...(activeToken ? { Authorization: `Bearer ${activeToken}` } : {}),
      ...(storedRole ? { "X-Demo-Role": storedRole } : {}),
      ...headers,
    },
  });

  const isJson = response.headers
    .get("content-type")
    ?.includes("application/json");
  const data = isJson ? await response.json() : await response.text();

  if (!response.ok) {
    let errorMessage: string | null = null;
    if (typeof data === "object" && data !== null) {
      if ("message" in data && typeof (data as { message: unknown }).message === "string") {
        errorMessage = (data as { message: string }).message;
      } else if ("detail" in data) {
        errorMessage = String((data as { detail: unknown }).detail);
      }
    }
    errorMessage = errorMessage || `API Error: ${response.status} ${response.statusText}`;
    throw new ApiError(errorMessage, response.status, data);
  }

  return data as T;
}

"use client";

import PageBreadcrumb from "@/components/common/PageBreadCrumb";
import FormField from "@/components/form/FormField";
import InputField from "@/components/form/input/InputField";
import Badge from "@/components/ui/badge/Badge";
import Button from "@/components/ui/button/Button";
import { Modal, ConfirmationModal } from "@/components/ui/modal";
import {
  Table,
  TableBody,
  TableCell,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  CheckCircleIcon,
  PlusIcon,
  TrashBinIcon,
} from "@/icons";
import { masterService } from "@/services";
import { NationalHoliday, OperationalPolicy } from "@/types/master";
import { useAuth } from "@/context/AuthContext";
import { useToast } from "@/context/ToastContext";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useMemo, useState } from "react";

const EMPTY_POLICY_DEFAULTS: OperationalPolicy = {
  work_start_time: "09:00",
  work_end_time: "17:00",
  friday_prayer_start: "11:30",
  friday_prayer_end: "13:00",
  max_negotiation_rounds: 3,
  buffer_minutes: 15,
  injection_guardrail_enabled: true,
};

const toHHMM = (value: string, fallback: string): string =>
  typeof value === "string" && value.length >= 4 ? value.slice(0, 5) : fallback;

const normalizePolicy = (policy: OperationalPolicy): OperationalPolicy => ({
  ...policy,
  work_start_time: toHHMM(policy.work_start_time, EMPTY_POLICY_DEFAULTS.work_start_time),
  work_end_time: toHHMM(policy.work_end_time, EMPTY_POLICY_DEFAULTS.work_end_time),
  friday_prayer_start: toHHMM(
    policy.friday_prayer_start,
    EMPTY_POLICY_DEFAULTS.friday_prayer_start
  ),
  friday_prayer_end: toHHMM(
    policy.friday_prayer_end,
    EMPTY_POLICY_DEFAULTS.friday_prayer_end
  ),
  max_negotiation_rounds:
    Number.isFinite(policy.max_negotiation_rounds)
      ? policy.max_negotiation_rounds
      : EMPTY_POLICY_DEFAULTS.max_negotiation_rounds,
  buffer_minutes: Number.isFinite(policy.buffer_minutes)
    ? policy.buffer_minutes
    : EMPTY_POLICY_DEFAULTS.buffer_minutes,
  injection_guardrail_enabled: Boolean(policy.injection_guardrail_enabled),
});

export default function OperationalRulesPage() {
  const { role } = useAuth();
  const canManageRules = role === "HR" || role === "ADMIN";
  const { showSuccess, showError } = useToast();
  const [isSaving, setIsSaving] = useState(false);
  const [isDeletingHoliday, setIsDeletingHoliday] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  // Confirmation Modals
  const [isConfirmPolicyOpen, setIsConfirmPolicyOpen] = useState(false);
  const [deleteTargetHoliday, setDeleteTargetHoliday] = useState<NationalHoliday | null>(null);

  // Add Holiday Modal
  const [isAddHolidayOpen, setIsAddHolidayOpen] = useState(false);
  const [isAddingHoliday, setIsAddingHoliday] = useState(false);
  const [newHolidayDate, setNewHolidayDate] = useState("");
  const [newHolidayName, setNewHolidayName] = useState("");
  const [newHolidayJointLeave, setNewHolidayJointLeave] = useState(false);

  // TanStack Query: Caches operational rules in memory with 1-min freshness and 0ms navigation
  const queryClient = useQueryClient();
  const { data: rulesData, isLoading } = useQuery({
    queryKey: ["operationalRules"],
    queryFn: async () => {
      const [apiPolicy, apiHolidays] = await Promise.all([
        masterService.getOperationalPolicy(),
        masterService.listHolidays(2026),
      ]);
      return {
        policy: apiPolicy && !Array.isArray(apiPolicy) ? normalizePolicy(apiPolicy) : null,
        holidays: Array.isArray(apiHolidays) ? apiHolidays : [],
      };
    },
  });

  const [formPolicy, setFormPolicy] = useState<OperationalPolicy | null>(null);
  const policy = formPolicy ?? rulesData?.policy ?? EMPTY_POLICY_DEFAULTS;
  const holidays = useMemo(() => rulesData?.holidays || [], [rulesData]);

  const setPolicy = (
    val: OperationalPolicy | ((prev: OperationalPolicy) => OperationalPolicy)
  ) => {
    if (typeof val === "function") {
      setFormPolicy((curr) => val(curr ?? rulesData?.policy ?? EMPTY_POLICY_DEFAULTS));
    } else {
      setFormPolicy(val);
    }
  };

  // Step 1: Trigger policy update confirmation
  const handleSavePolicy = () => {
    setIsConfirmPolicyOpen(true);
  };

  // Step 2: Execute policy update upon user confirmation
  const handleExecuteSavePolicy = async () => {
    const normalizedPolicy = normalizePolicy(policy);
    setIsSaving(true);
    try {
      const savedPolicy = await masterService.updateOperationalPolicy(normalizedPolicy);
      const finalPolicy = savedPolicy && !Array.isArray(savedPolicy) ? normalizePolicy(savedPolicy) : normalizedPolicy;
      queryClient.setQueryData(
        ["operationalRules"],
        (old: { policy: OperationalPolicy | null; holidays: NationalHoliday[] } | undefined) => ({
          policy: finalPolicy,
          holidays: old?.holidays || [],
        })
      );
      setFormPolicy(null);
      setSaveSuccess(true);
      showSuccess("Successfully Saved", "Operational policies and AI Orchestrator limits successfully updated.");
      void queryClient.invalidateQueries({ queryKey: ["operationalRules"] });
      setIsConfirmPolicyOpen(false);
      setTimeout(() => setSaveSuccess(false), 3000);
    } catch (error) {
      console.error("Failed to update operational policy:", error);
      showError(
        "Failed to Save",
        error instanceof Error ? error.message : "An error occurred while updating operational policies."
      );
    } finally {
      setIsSaving(false);
    }
  };

  // Add Holiday Handler
  const handleAddHoliday = async () => {
    if (!newHolidayDate || !newHolidayName.trim()) {
      showError("Validation Failed", "Please provide both the date and name of the holiday.");
      return;
    }

    setIsAddingHoliday(true);
    try {
      const createdHoliday = await masterService.createHoliday({
        date: newHolidayDate,
        name: newHolidayName,
        is_joint_leave: newHolidayJointLeave,
      });
      if (createdHoliday) {
        queryClient.setQueryData(
          ["operationalRules"],
          (old: { policy: OperationalPolicy | null; holidays: NationalHoliday[] } | undefined) => ({
            policy: old?.policy || null,
            holidays: [
              createdHoliday,
              ...(old?.holidays || []).filter((h) => h.id !== createdHoliday.id),
            ],
          })
        );
      }
      showSuccess("Holiday Added", `Holiday "${newHolidayName}" successfully added to the calendar.`);
      void queryClient.invalidateQueries({ queryKey: ["operationalRules"] });
      setNewHolidayDate("");
      setNewHolidayName("");
      setNewHolidayJointLeave(false);
      setIsAddHolidayOpen(false);
    } catch (error) {
      console.error("Failed to create holiday:", error);
      showError(
        "Failed to Add",
        error instanceof Error ? error.message : "An error occurred while adding the holiday."
      );
    } finally {
      setIsAddingHoliday(false);
    }
  };

  // Step 1: Open Holiday Delete Confirmation
  const handleOpenDeleteHoliday = (item: NationalHoliday) => {
    setDeleteTargetHoliday(item);
  };

  // Step 2: Confirm Delete Holiday (Wired to DELETE /api/v1/holidays/{id})
  const handleConfirmDeleteHoliday = async () => {
    if (!deleteTargetHoliday) return;
    const deletedName = deleteTargetHoliday.name;
    const targetId = deleteTargetHoliday.id;
    setIsDeletingHoliday(true);
    try {
      await masterService.deleteHoliday(targetId);
      queryClient.setQueryData(
        ["operationalRules"],
        (old: { policy: OperationalPolicy | null; holidays: NationalHoliday[] } | undefined) => ({
          policy: old?.policy || null,
          holidays: (old?.holidays || []).filter((h) => h.id !== targetId),
        })
      );
      void queryClient.invalidateQueries({ queryKey: ["operationalRules"] });
      setDeleteTargetHoliday(null);
      showSuccess("Holiday Deleted", `Holiday "${deletedName}" successfully removed from the database.`);
    } catch (error) {
      console.error("Failed to delete holiday:", error);
      showError(
        "Failed to Delete",
        error instanceof Error ? error.message : "An error occurred while deleting the holiday."
      );
    } finally {
      setIsDeletingHoliday(false);
    }
  };

  return (
    <div>
      <PageBreadcrumb pageTitle="Operational Rules & Calendar" />

      {/* Success Notification Alert */}
      {saveSuccess && (
        <div className="mb-5 flex items-center gap-3 rounded-xl border border-success-200 bg-success-50 p-4 text-xs font-medium text-success-800 dark:border-success-500/20 dark:bg-success-500/15 dark:text-success-300 animate-in fade-in">
          <CheckCircleIcon className="text-success-500 shrink-0" />
          <span>The operational rules were successfully cached in the AI Orchestrator</span>
        </div>
      )}

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        {/* Left Column: Work Policy Settings */}
        <div className="lg:col-span-5 space-y-6">
          <div className="rounded-2xl border border-gray-200 bg-white p-5 xl:p-6 dark:border-gray-800 dark:bg-gray-900 shadow-theme-xs">
            <div className="border-b border-gray-100 pb-4 dark:border-gray-800">
              <h3 className="text-theme-xl font-semibold text-gray-800 dark:text-white/90">
                Rules on Working Hours and Worship
              </h3>
              <p className="mt-0.5 text-xs text-gray-500 dark:text-gray-400">
                AI is prohibited from creating schedules outside operational hours or during Friday prayers.
              </p>
            </div>

            <div className="mt-5 space-y-4">
              {/* Working Hours */}
              <div className="grid grid-cols-2 gap-3">
                <FormField label="Work Start Time">
                  <InputField
                    type="time"
                    value={policy.work_start_time}
                    onChange={(e) => setPolicy({ ...policy, work_start_time: e.target.value })}
                  />
                </FormField>
                <FormField label="Work End Time">
                  <InputField
                    type="time"
                    value={policy.work_end_time}
                    onChange={(e) => setPolicy({ ...policy, work_end_time: e.target.value })}
                  />
                </FormField>
              </div>

              {/* Friday Prayer Block */}
              <div className="rounded-xl border border-gray-200 bg-gray-50/70 p-4 dark:border-gray-800 dark:bg-gray-800/40">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-semibold text-gray-800 dark:text-white/90">
                    Friday Prayer Block (Mandatory)
                  </span>
                  <Badge color="error" size="sm">Auto Block</Badge>
                </div>
                <div className="grid grid-cols-2 gap-3 mt-3">
                  <FormField label="Start (WIB)">
                    <InputField
                      type="time"
                      value={policy.friday_prayer_start}
                      onChange={(e) => setPolicy({ ...policy, friday_prayer_start: e.target.value })}
                    />
                  </FormField>
                  <FormField label="End (WIB)">
                    <InputField
                      type="time"
                      value={policy.friday_prayer_end}
                      onChange={(e) => setPolicy({ ...policy, friday_prayer_end: e.target.value })}
                    />
                  </FormField>
                </div>
                <div className="mt-2 text-[11px] text-gray-400 leading-relaxed">
                  • <strong>WITA</strong>: automatically converted to 12:30 – 14:00.<br />
                  • <strong>WIT</strong>: automatically converted to 13:30 – 15:00.
                </div>
              </div>

              {/* Triage Limits */}
              <div className="grid grid-cols-2 gap-3">
                <FormField label="Maximum Number of Triage Rounds">
                  <InputField
                    type="number"
                    min={1}
                    max={5}
                    value={policy.max_negotiation_rounds}
                    onChange={(e) => setPolicy({ ...policy, max_negotiation_rounds: parseInt(e.target.value) || 3 })}
                  />
                </FormField>
                <FormField label="Buffer Time Between Sessions (Minutes)">
                  <InputField
                    type="number"
                    min={0}
                    max={60}
                    step={5}
                    value={policy.buffer_minutes}
                    onChange={(e) => setPolicy({ ...policy, buffer_minutes: parseInt(e.target.value) || 15 })}
                  />
                </FormField>
              </div>

              {/* Guardrail Toggle */}
              <div className="flex items-center justify-between rounded-xl border border-gray-200 p-3.5 dark:border-gray-800">
                <div>
                  <div className="text-xs font-semibold text-gray-800 dark:text-white/90">
                    Prompt Injection Guardrail
                  </div>
                  <div className="text-[11px] text-gray-400">
                    Scan for malicious instructions in CV & WhatsApp messages
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={policy.injection_guardrail_enabled}
                  onChange={(e) => setPolicy({ ...policy, injection_guardrail_enabled: e.target.checked })}
                  className="h-4 w-4 rounded border-gray-300 text-brand-600 focus:ring-brand-500"
                />
              </div>

              <div className="pt-2">
                <Button
                  variant="primary"
                  className="w-full"
                  onClick={handleSavePolicy}
                  disabled={!canManageRules || isSaving}
                  title={!canManageRules ? "Only HR or Admin can update operational rules." : undefined}
                >
                  {isSaving ? "Saving Changes..." : "Save Operational Rules"}
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: National Holidays 2026 */}
        <div className="lg:col-span-7">
          <div className="rounded-2xl border border-gray-200 bg-white p-5 xl:p-6 dark:border-gray-800 dark:bg-gray-900 shadow-theme-xs">
            <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between border-b border-gray-100 pb-4 dark:border-gray-800">
              <div>
                <h3 className="text-theme-xl font-semibold text-gray-800 dark:text-white/90">
                  National Holidays
                </h3>
                <p className="mt-0.5 text-xs text-gray-500 dark:text-gray-400">
                  Official calendar. AI automatically blocks all interview slots on these dates.
                </p>
              </div>
              <Button
                variant="outline"
                size="sm"
                startIcon={<PlusIcon/>}
                onClick={() => setIsAddHolidayOpen(true)}
                disabled={!canManageRules}
                title={!canManageRules ? "Only HR or Admin can add holidays." : undefined}
              >
                Add Holiday
              </Button>
            </div>

            {/* Holidays Table */}
            <div className="mt-5 overflow-x-auto rounded-xl border border-gray-200 dark:border-gray-800">
              <Table>
                <TableHeader className="bg-gray-50 dark:bg-gray-800/60 border-b border-gray-200 dark:border-gray-800">
                  <TableRow>
                    <TableCell isHeader className="ps-4 pe-3 py-3 text-start text-xs font-semibold text-gray-600 dark:text-gray-300">
                      Date
                    </TableCell>
                    <TableCell isHeader className="px-3 py-3 text-start text-xs font-semibold text-gray-600 dark:text-gray-300">
                      Holiday Name
                    </TableCell>
                    <TableCell isHeader className="px-3 py-3 text-start text-xs font-semibold text-gray-600 dark:text-gray-300">
                      Type
                    </TableCell>
                    <TableCell isHeader className="pe-5 ps-3 py-3 text-end text-xs font-semibold text-gray-600 dark:text-gray-300">
                      Actions
                    </TableCell>
                  </TableRow>
                </TableHeader>
                <TableBody className="divide-y divide-gray-100 dark:divide-gray-800">
                  {isLoading ? (
                    <TableRow>
                      <TableCell colSpan={4} className="py-8 text-center text-xs text-gray-400">
                        Loading holidays from database...
                      </TableCell>
                    </TableRow>
                  ) : holidays.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={4} className="py-8 text-center text-xs text-gray-400">
                        No holidays registered in the database.
                      </TableCell>
                    </TableRow>
                  ) : (
                    holidays.map((h) => (
                      <TableRow key={h.id} className="hover:bg-gray-50/70 dark:hover:bg-white/[0.02] transition-colors">
                        <TableCell className="ps-4 pe-3 py-3 text-xs font-mono font-medium text-gray-800 dark:text-gray-200">
                          {h.date}
                        </TableCell>
                        <TableCell className="px-3 py-3 text-xs text-gray-700 dark:text-gray-300 font-medium">
                          {h.name}
                        </TableCell>
                        <TableCell className="px-3 py-3">
                          {h.is_joint_leave ? (
                            <Badge color="warning" size="sm">Cuti Bersama</Badge>
                          ) : (
                            <Badge color="error" size="sm">Libur Nasional</Badge>
                          )}
                        </TableCell>
                        <TableCell className="pe-5 ps-3 py-3 text-end whitespace-nowrap">
                          {canManageRules ? (
                            <button
                              type="button"
                              onClick={() => handleOpenDeleteHoliday(h)}
                              className="h-8 w-8 inline-flex items-center justify-center rounded-lg border border-gray-200 bg-white text-gray-500 shadow-theme-xs hover:border-error-300 hover:bg-error-50 hover:text-error-600 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:hover:border-error-500/30 dark:hover:bg-error-500/15 dark:hover:text-error-400 transition-all"
                              title="Delete Holiday"
                            >
                              <TrashBinIcon/>
                            </button>
                          ) : (
                            <span className="text-xs text-gray-400 italic">Read-only</span>
                          )}
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>

            <div className="mt-4 flex items-center justify-between text-xs text-gray-400">
              <span>{holidays.length} holidays registered in AI calendar</span>
            </div>
          </div>
        </div>
      </div>

      {/* Add Holiday Modal */}
      <Modal isOpen={isAddHolidayOpen} onClose={() => setIsAddHolidayOpen(false)} className="max-w-2xl m-4">
        <div className="p-10">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
            Add New Holiday
          </h3>
          <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
            Register holiday or joint leave so that AI does not schedule interviews on this date.
          </p>

          <div className="mt-5 space-y-3.5">
            <FormField label="Holiday Date" required>
              <InputField
                type="date"
                value={newHolidayDate}
                onChange={(e) => setNewHolidayDate(e.target.value)}
              />
            </FormField>

            <FormField label="Holiday Name" required>
              <InputField
                placeholder="e.g., Company Additional Joint Leave"
                value={newHolidayName}
                onChange={(e) => setNewHolidayName(e.target.value)}
              />
            </FormField>

            <div className="flex items-center gap-2 pt-1">
              <input
                type="checkbox"
                id="isJointLeave"
                checked={newHolidayJointLeave}
                onChange={(e) => setNewHolidayJointLeave(e.target.checked)}
                className="h-4 w-4 rounded border-gray-300 text-brand-600 focus:ring-brand-500"
              />
              <label htmlFor="isJointLeave" className="text-xs text-gray-700 dark:text-gray-300 cursor-pointer">
                Mark as <strong>Joint Leave</strong>
              </label>
            </div>
          </div>

          <div className="mt-6 flex justify-end gap-2.5 pt-3 border-t border-gray-100 dark:border-gray-800">
            <Button variant="outline" onClick={() => setIsAddHolidayOpen(false)}>
              Cancel
            </Button>
            <Button variant="primary" onClick={handleAddHoliday} disabled={isAddingHoliday}>
              {isAddingHoliday ? "Adding..." : "Add to Calendar"}
            </Button>
          </div>
        </div>
      </Modal>

      {/* Policy Save Confirmation Modal */}
      <ConfirmationModal
        isOpen={isConfirmPolicyOpen}
        onClose={() => setIsConfirmPolicyOpen(false)}
        onConfirm={handleExecuteSavePolicy}
        isLoading={isSaving}
        title="Confirm Update Operational Rules"
        description="Are you sure you want to apply these operational policies and AI limits? The changes will immediately affect interview slot screening."
        confirmText="Yes, Apply Changes"
        cancelText="Cancel"
        variant="primary"
      />

      {/* Holiday Delete Confirmation Modal */}
      <ConfirmationModal
        isOpen={!!deleteTargetHoliday}
        onClose={() => setDeleteTargetHoliday(null)}
        onConfirm={handleConfirmDeleteHoliday}
        isLoading={isDeletingHoliday}
        title="Confirm Delete Holiday"
        description={`Are you sure you want to remove "${deleteTargetHoliday?.name}" from the calendar? The AI will resume scheduling interviews on this date.`}
        confirmText="Yes, Delete"
        cancelText="Cancel"
        variant="danger"
      />
    </div>
  );
}
